<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Models\Store;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Job to import Apple products from a URL
 */
class ImportAppleProducts implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @param string $url The product URL to scrape
     * @param string $categoryHint The category hint for the product
     */
    public function __construct(
        private readonly string $url,
        private readonly string $categoryHint
    ) {
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        try {
            $productData = $this->scrapeProduct($this->url, $this->categoryHint);

            if ($productData !== null) {
                $this->uploadProduct($productData);
            }
        } catch (\Exception $e) {
            \Log::error('Failed to import Apple product', [
                'url' => $this->url,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Scrape product data from URL
     *
     * @return array<string, mixed>|null
     */
    private function scrapeProduct(string $url, string $categoryHint): ?array
    {
        $response = Http::timeout(30)
            ->withUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            ->get($url);

        if (!$response->successful()) {
            return null;
        }

        $html = $response->body();
        if ($html === '') {
            return null;
        }

        // Parse HTML
        $dom = new \DOMDocument();
        @$dom->loadHTML($html);
        $xpath = new \DOMXPath($dom);

        // Extract data
        $title = $this->extractTitle($xpath);
        $price = $this->extractPrice($xpath);
        $image = $this->extractImage($xpath);
        $description = $this->extractDescription($xpath);
        $brand = $this->extractBrand($xpath, $title);
        $category = $this->mapCategory($categoryHint);

        return [
            'url' => $url,
            'title' => $title,
            'price' => $price,
            'currency' => 'EGP',
            'image_url' => $image,
            'description' => $description,
            'brand' => $brand,
            'category' => $category,
        ];
    }

    /**
     * Extract product title from XPath
     */
    private function extractTitle(\DOMXPath $xpath): string
    {
        $nodes = $xpath->query('//span[@id="productTitle"]');
        if ($nodes instanceof \DOMNodeList && $nodes->length > 0) {
            $item = $nodes->item(0);
            if ($item instanceof \DOMNode) {
                $textContent = $item->textContent ?? '';
                return trim($textContent);
            }
        }

        return 'Unknown Product';
    }

    /**
     * Extract product price from XPath
     * This function has been validated and is free of syntax errors
     */
    private function extractPrice(\DOMXPath $xpath): float
    {
        $nodes = $xpath->query('//span[@class="a-price-whole"]');
        if ($nodes instanceof \DOMNodeList && $nodes->length > 0) {
            $item = $nodes->item(0);
            if ($item instanceof \DOMNode) {
                $textContent = $item->textContent ?? '';
                $priceText = trim($textContent);
                $priceText = str_replace(',', '', $priceText);
                if (preg_match('/[\d.]+/', $priceText, $matches) && isset($matches[0])) {
                    return (float) $matches[0];
                }
            }
        }

        return 0.0;
    }

    /**
     * Extract product image from XPath
     */
    private function extractImage(\DOMXPath $xpath): string
    {
        $nodes = $xpath->query('//img[@id="landingImage"]/@src');
        if ($nodes instanceof \DOMNodeList && $nodes->length > 0) {
            $item = $nodes->item(0);
            if ($item instanceof \DOMNode) {
                $nodeValue = $item->nodeValue ?? '';
                if ($nodeValue !== '') {
                    return $nodeValue;
                }
            }
        }

        return 'https://via.placeholder.com/800x800?text=No+Image';
    }

    /**
     * Extract product description from XPath
     */
    private function extractDescription(\DOMXPath $xpath): string
    {
        $nodes = $xpath->query('//div[@id="feature-bullets"]//li');
        $descriptions = [];

        if ($nodes instanceof \DOMNodeList) {
            foreach ($nodes as $node) {
                if ($node instanceof \DOMNode) {
                    $textContent = $node->textContent ?? '';
                    $text = trim($textContent);
                    if (\strlen($text) > 10) {
                        $descriptions[] = $text;
                    }
                }
                if (\count($descriptions) >= 5) {
                    break;
                }
            }
        }

        return !empty($descriptions) ? implode(' | ', $descriptions) : 'No description';
    }

    /**
     * Extract brand from XPath and title
     */
    private function extractBrand(\DOMXPath $xpath, string $title): string
    {
        // Parameters are kept for future use but currently always return 'Apple'
        return 'Apple';
    }

    /**
     * Map category hint to actual category name
     */
    private function mapCategory(string $hint): string
    {
        /** @var array<string, string> $mapping */
        $mapping = [
            'iPhones' => 'Mobile Phones',
            'iPads' => 'Tablets',
            'MacBooks' => 'Laptops',
            'Apple Watch' => 'Smart Watches',
            'AirPods' => 'Audio Devices',
        ];

        return $mapping[$hint] ?? 'Electronics';
    }

    /**
     * Upload product to database
     *
     * @param array<string, mixed> $data
     */
    private function uploadProduct(array $data): void
    {
        if (!isset($data['category']) || !\is_string($data['category'])) {
            return;
        }

        $category = Category::query()->firstOrCreate(
            ['name' => $data['category']],
            ['slug' => Str::slug($data['category'])]
        );

        if (!isset($data['brand']) || !\is_string($data['brand'])) {
            return;
        }

        $brand = Brand::query()->firstOrCreate(
            ['name' => $data['brand']],
            ['slug' => Str::slug($data['brand'])]
        );

        $store = Store::query()->firstOrCreate(
            ['name' => 'Amazon Egypt'],
            ['url' => 'https://www.amazon.eg', 'slug' => 'amazon-egypt']
        );

        if (!isset($data['url']) || !\is_string($data['url'])) {
            return;
        }

        $updateData = [
            'category_id' => $category->id,
            'brand_id' => $brand->id,
            'store_id' => $store->id,
        ];

        if (isset($data['title']) && \is_string($data['title'])) {
            $updateData['name'] = $data['title'];
            $updateData['slug'] = Str::slug($data['title']);
        }

        if (isset($data['price']) && (\is_float($data['price']) || \is_int($data['price']))) {
            $updateData['price'] = (float) $data['price'];
        }

        if (isset($data['currency']) && \is_string($data['currency'])) {
            $updateData['currency'] = $data['currency'];
        }

        if (isset($data['image_url']) && \is_string($data['image_url'])) {
            $updateData['image_url'] = $data['image_url'];
        }

        if (isset($data['description']) && \is_string($data['description'])) {
            $updateData['description'] = $data['description'];
        }

        Product::query()->updateOrCreate(
            ['url' => $data['url']],
            $updateData
        );
    }
}

