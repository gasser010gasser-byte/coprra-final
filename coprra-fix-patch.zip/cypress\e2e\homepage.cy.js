describe('Homepage E2E Tests', () => {
  beforeEach(() => {
    // Visit the homepage before each test
    cy.visit('/');
  });

  it('should load the homepage successfully', () => {
    // Verify the page loads with status 200
    cy.url().should('include', '/');
    cy.get('body').should('be.visible');
  });

  it('should have a valid HTML structure', () => {
    // Check for basic HTML elements
    cy.get('html').should('exist');
    cy.get('head').should('exist');
    cy.get('body').should('exist');
  });

  it('should be accessible via baseUrl', () => {
    // Verify the baseUrl is correctly configured
    cy.request({
      url: '/',
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.eq(200);
    });
  });
});

describe('Health Check E2E Tests', () => {
  it('should access health endpoint', () => {
    cy.request('/health').then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body).to.exist;
    });
  });

  it('should access health check endpoint', () => {
    cy.request('/health/check').then((response) => {
      expect(response.status).to.eq(200);
    });
  });

  it('should access health ping endpoint', () => {
    cy.request('/health/ping').then((response) => {
      expect(response.status).to.eq(200);
    });
  });
});

